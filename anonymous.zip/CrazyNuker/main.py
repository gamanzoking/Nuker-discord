from keep_alive import keep_alive
import bot

keep_alive()